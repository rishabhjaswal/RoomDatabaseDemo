#Android MVVM with RoomDatabase and Dagger-Hilt

so hey guys in this project we are going to make a todo app with the help of room database and dagger-hilt( it provides dependencies injection)

<p align="center">
<img src="app/src/main/res/drawable/demo.png"/>
</p>
